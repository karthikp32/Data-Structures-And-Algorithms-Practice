import pytesseract
from pdf2image import convert_from_path
from PIL import Image
import os

def pdf_to_text(pdf_path):
    # Convert PDF to a list of images
    images = convert_from_path(pdf_path)

    # Folder to store temporary images if needed
    temp_folder = "temp_images"
    os.makedirs(temp_folder, exist_ok=True)
    
    full_text = []

    # Process each page/image in the PDF
    for i, image in enumerate(images):
        # Save image to temporary file to improve OCR quality
        temp_image_path = os.path.join(temp_folder, f"page_{i}.png")
        image.save(temp_image_path, 'PNG')

        # Perform OCR using Tesseract
        text = pytesseract.image_to_string(Image.open(temp_image_path))
        
        # Append the text of each image to the full text list
        full_text.append(text)

        # Optional: Remove temp image file if desired
        os.remove(temp_image_path)

    # Optional: Remove the temp folder if no longer needed
    os.rmdir(temp_folder)
    
    return '\n'.join(full_text)

# Example usage:
# text_output = pdf_to_text('path_to_your_pdf_file.pdf')
# print(text_output)
